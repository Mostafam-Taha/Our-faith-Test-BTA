document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.getElementById('login-form');

    // Handle login form submission
    loginForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const username = document.getElementById('username').value;
        const profilePic = document.getElementById('profile-pic').files[0];

        const reader = new FileReader();
        reader.onload = function (e) {
            localStorage.setItem('username', username);
            localStorage.setItem('profilePic', e.target.result);
            localStorage.setItem('isLoggedIn', 'true');
            window.location.href = "index.html"; // Redirect to main page after login
        };
        reader.readAsDataURL(profilePic);
    });
});
